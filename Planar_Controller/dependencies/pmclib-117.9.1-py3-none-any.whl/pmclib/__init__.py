import sys
import sysconfig
import clr

sys.path.insert(0,f"{sysconfig.get_path('platlib')}/pmclib")
clr.AddReference('PMCLIB')