from enum import IntEnum
from typing import List
from typing import NamedTuple
from enum import Enum
import datetime
from PMCLIB.Trace import TraceHelper
import PMCLIB.Trace
from typing import List
from System import Enum
from System import UInt16
from pmclib import pmc_types as pm
from PMCLIB import PMCRTN
import PMCLIB


class PmcError(Exception):
	""" PMC Error Exception
	"""

	def __init__(self, *args : object) -> None:
		super().__init__(*args)


def assert_type(checkvar, checkType: type, varName: str=""):
	"""Assert the input variable is of the correct type

	Parameters
	----------
	var: Any
		Variable to check
	checkType : type
		Type that the variable is asserted to be
	varName : str
		Name of the variable
	"""

	if checkType == float and (type(checkvar) == int or type(checkvar == float)):
		return

	if not isinstance(checkvar, checkType):
		raise TypeError(
			f"{varName} expected {checkType}, got {type(checkvar)}")


class TRACETRIGGEREVENT(IntEnum):
	"""Enum for the Trigger Event

	Options
	----------
	SW_TRIGGER = 1:
		Software Trigger
	MOTION_START_TRIGGER = 2:
		Triggers Trace After Motion Started
	MOTION_STOP_TRIGGER = 3:
		Triggers Trace After Motion Stopped
	FIELDBUS_TRIGGER = 7:
		Triggers Trace After Fieldbus digital input (rising edge)
	"""
	SW_TRIGGER = 1,
	MOTION_START_TRIGGER = 2,
	MOTION_STOP_TRIGGER = 3,
	FIELDBUS_TRIGGER = 7,
	
class TraceAxis(IntEnum):
	"""Axis options to trace

	Options
	----------
	X = 0:
		X Axis
	Y = 1:
		Y Axis
	Z = 2:
		Z Axis
	Rx = 3:
		Rx Axis
	Ry = 4:
		Ry Axis
	Rz = 5:
		Rz Axis
	"""
	X = 0,
	Y = 1,
	Z = 2,
	Rx = 3,
	Ry = 4,
	Rz = 5,
	
class SignalOption(IntEnum):
	"""Signal Option (Reference or Feedback)

	Options
	----------
	Reference = 0:
		Reference
	Feedback = 1:
		Feedback
	"""
	Reference = 0,
	Feedback = 1,
	
class ITraceTrigger():
	"""Trace Trigger Interface

	Options
	----------
	trig_type: TRACETRIGGEREVENT
		Triger Type
	xbot_id: int
		The ID of the XBot that triggers the trace
	"""
	def __init__(self,trig_type:TRACETRIGGEREVENT,xbot_id:int):
		self.trig_type = trig_type
		self.xbot_id = xbot_id
		

class SoftwareTrigger(ITraceTrigger):
	"""Object for Software Trigger

	Fields
	---------
	trig_type: TRACETRIGGEREVENT
		Triger Type (Software Trigger)
	xbot_id: int
		The ID of the XBot that triggers the trace.
		For software-triggered traces, this value is not needed and is always set to 0.
	"""

	def __init__(self):
		self.trig_type = TRACETRIGGEREVENT(1)
		self.xbot_id = 0
		super().__init__(self.trig_type, self.xbot_id)


class MotionStartTrigger(ITraceTrigger):
	"""Object for Motion Trigger

	Fields
	---------
	trig_type: TRACETRIGGEREVENT
		Trigger Type (Motion Start Trigger)
	xbot_id: int
		The ID of the XBot that triggers the trace
	"""

	def __init__(self, xbot_id):
		self.trig_type = TRACETRIGGEREVENT(2)
		self.xbot_id = xbot_id
		super().__init__(self.trig_type, self.xbot_id)


class MotionStopTrigger(ITraceTrigger):
	"""Object for Motion Trigger

	Fields
	---------
	trig_type: TRACETRIGGEREVENT
		Trigger Type (Motion Stop Trigger)
	xbot_id: int
		The ID of the XBot that triggers the trace
	"""

	def __init__(self, xbot_id):
		self.trig_type = TRACETRIGGEREVENT(3)
		self.xbot_id = xbot_id
		super().__init__(self.trig_type, self.xbot_id)


class FieldbusTrigger(ITraceTrigger):
	"""Object for fieldbus Trigger

	Fields
	---------
	trig_type: TRACETRIGGEREVENT
		Trigger Type (Motion Stop Trigger)
	xbot_id: int
		The ID of the XBot that triggers the trace
		For fieldbus-triggered traces, this value is used to store the bit that
		triggers the event. Can be 1-128.
	"""

	def __init__(self, fb_trigger):
		self.trig_type = TRACETRIGGEREVENT(7)
		self.xbot_id = fb_trigger
		super().__init__(self.trig_type, self.xbot_id)

class SingleTrace:
	"""Single Trace Object
	Members
	----------
	is_trace_ready: bool
		Indicates If the Trace Data is Ready or Not
	trace_data_array: double[]
		Traced Data
	mover_id: int
		Mover ot Tile ID
	trace_start_trigger: ITraceTrigger
		Trace Trigger Event Object
	trace_duration_sec: double
		Trace Duration in Second
	"""

	def __init__(self, rtn):
		self.__rtn = rtn

	@property
	def is_trace_ready(self):
		return self.__rtn.IsTraceReady

	@property
	def trace_data_array(self):
		return self.__rtn.TraceDataArray

	@property
	def mover_id(self):
		return self.__rtn.MoverID

	@property
	def trace_start_trigger(self):
		return self.__rtn.TraceStartTrigger

	@property
	def trace_duration_sec(self):
		return self.__rtn.TraceDurationSec

	
def trace_position(
	axis: TraceAxis,
	signal_option: SignalOption,
	xbot_id: int,
	trace_duration: float,
	start_trigger_event: ITraceTrigger
):
	"""Traces the XBot position for the specified axis.

	Parameters
	----------
	axis: TraceAxis
		The axis to trace for force.
	signal_option: SignalOption
		Specifies whether to trace the reference or feedback signal.
	xbot_id: int
		The ID of the XBot to trace.
	trace_duration: float
		Duration of the trace in seconds.
	start_trigger_event: ITraceTrigger
		Event that triggers the trace (e.g., SoftwareTrigger or MotionTrigger)

	"""
	assert_type(axis, TraceAxis, "axis")
	assert_type(signal_option, SignalOption, "signal_option")
	assert_type(xbot_id, int, "xbot_id")
	assert_type(trace_duration, float, "trace_duration")
	assert_type(start_trigger_event, ITraceTrigger, "start_trigger_event")
	
	axis_enum = PMCLIB.Trace.TraceAxis(axis)
	signal_option_enum = PMCLIB.Trace.SignalOption(signal_option)

	if start_trigger_event.trig_type == 1:
		start_trigger_event_enum = PMCLIB.Trace.SoftwareTrigger()
	if start_trigger_event.trig_type == 2:
		start_trigger_event_enum = PMCLIB.Trace.MotionStartTrigger(start_trigger_event.xbot_id)
	if start_trigger_event.trig_type == 3:
		start_trigger_event_enum = PMCLIB.Trace.MotionStopTrigger(start_trigger_event.xbot_id)
	if start_trigger_event.trig_type == 7:
		start_trigger_event_enum = PMCLIB.Trace.FieldbusTrigger(start_trigger_event.fb_trigger)


	rtn = TraceHelper.TracePosition(axis_enum,signal_option_enum,int(xbot_id),float(trace_duration),start_trigger_event_enum)

	return SingleTrace(rtn)


def trace_force(
	axis: TraceAxis,
	signal_option: SignalOption,
	xbot_id: int,
	trace_duration: float,
	start_trigger_event: ITraceTrigger
):
	"""Traces the XBot force for the specified axis.

	Parameters
	----------
	axis: TraceAxis
		The axis to trace for force.
	signal_option: SignalOption
		Specifies whether to trace the reference or feedback signal.
	xbot_id: int
		The ID of the XBot to trace.
	trace_duration: float
		Duration of the trace in seconds.
	start_trigger_event: ITraceTrigger
		Event that triggers the trace (e.g., SoftwareTrigger or MotionTrigger).

	"""
	assert_type(axis, TraceAxis, "axis")
	assert_type(signal_option, SignalOption, "signal_option")
	assert_type(xbot_id, int, "xbot_id")
	assert_type(trace_duration, float, "trace_duration")
	assert_type(start_trigger_event, ITraceTrigger, "start_trigger_event")
	
	axis_enum = PMCLIB.Trace.TraceAxis(axis)
	signal_option_enum = PMCLIB.Trace.SignalOption(signal_option)

	if start_trigger_event.trig_type == 1:
		start_trigger_event_enum = PMCLIB.Trace.SoftwareTrigger()
	if start_trigger_event.trig_type == 2:
		start_trigger_event_enum = PMCLIB.Trace.MotionStartTrigger(start_trigger_event.xbot_id)
	if start_trigger_event.trig_type == 3:
		start_trigger_event_enum = PMCLIB.Trace.MotionStopTrigger(start_trigger_event.xbot_id)
	if start_trigger_event.trig_type == 7:
		start_trigger_event_enum = PMCLIB.Trace.FieldbusTrigger(start_trigger_event.fb_trigger)


	rtn = TraceHelper.TraceForce(axis_enum,signal_option_enum,int(xbot_id),float(trace_duration),start_trigger_event_enum)

	return SingleTrace(rtn)


def trace_position_error(
	axis: TraceAxis,
	xbot_id: int,
	trace_duration: float,
	start_trigger_event: ITraceTrigger
):
	"""Traces the XBot position error for the specified axis.

	Parameters
	----------
	axis: TraceAxis
		The axis to trace for position error.
	xbot_id: int
		The ID of the XBot to trace.
	trace_duration: float
		Duration of the trace in seconds.
	start_trigger_event: ITraceTrigger
		Event that triggers the trace (e.g., SoftwareTrigger or MotionTrigger).

	"""
	assert_type(axis, TraceAxis, "axis")
	assert_type(xbot_id, int, "xbot_id")
	assert_type(trace_duration, float, "trace_duration")
	assert_type(start_trigger_event, ITraceTrigger, "start_trigger_event")
	
	axis_enum = PMCLIB.Trace.TraceAxis(axis)

	if start_trigger_event.trig_type == 1:
		start_trigger_event_enum = PMCLIB.Trace.SoftwareTrigger()
	if start_trigger_event.trig_type == 2:
		start_trigger_event_enum = PMCLIB.Trace.MotionStartTrigger(start_trigger_event.xbot_id)
	if start_trigger_event.trig_type == 3:
		start_trigger_event_enum = PMCLIB.Trace.MotionStopTrigger(start_trigger_event.xbot_id)
	if start_trigger_event.trig_type == 7:
		start_trigger_event_enum = PMCLIB.Trace.FieldbusTrigger(start_trigger_event.fb_trigger)


	rtn = TraceHelper.TracePositionError(axis_enum,int(xbot_id),float(trace_duration),start_trigger_event_enum)

	return SingleTrace(rtn)


def trace_xbot_state(
	xbot_id: int,
	trace_duration: float,
	start_trigger_event: ITraceTrigger
):
	"""Traces the state of the XBot over a specified duration.

	Parameters
	----------
	xbot_id: int
		The ID of the XBot to trace.
	trace_duration: float
		Duration of the trace in seconds.
	start_trigger_event: ITraceTrigger
		Event that triggers the trace (e.g., SoftwareTrigger or MotionTrigger).

	"""
	assert_type(xbot_id, int, "xbot_id")
	assert_type(trace_duration, float, "trace_duration")
	assert_type(start_trigger_event, ITraceTrigger, "start_trigger_event")
	

	if start_trigger_event.trig_type == 1:
		start_trigger_event_enum = PMCLIB.Trace.SoftwareTrigger()
	if start_trigger_event.trig_type == 2:
		start_trigger_event_enum = PMCLIB.Trace.MotionStartTrigger(start_trigger_event.xbot_id)
	if start_trigger_event.trig_type == 3:
		start_trigger_event_enum = PMCLIB.Trace.MotionStopTrigger(start_trigger_event.xbot_id)
	if start_trigger_event.trig_type == 7:
		start_trigger_event_enum = PMCLIB.Trace.FieldbusTrigger(start_trigger_event.fb_trigger)


	rtn = TraceHelper.TraceXbotState(int(xbot_id),float(trace_duration),start_trigger_event_enum)

	return SingleTrace(rtn)


def trace_flyway_power_consumption(
	flyway_id: int,
	trace_duration: float,
	start_trigger_event: ITraceTrigger
):
	"""Traces Flyway power consumption over a specified duration.

	Parameters
	----------
	flyway_id: int
		The ID of the Flyway to trace.
	trace_duration: float
		Duration of the trace in seconds.
	start_trigger_event: ITraceTrigger
		Event that triggers the trace (e.g., SoftwareTrigger or MotionTrigger).

	"""
	assert_type(flyway_id, int, "flyway_id")
	assert_type(trace_duration, float, "trace_duration")
	assert_type(start_trigger_event, ITraceTrigger, "start_trigger_event")
	

	if start_trigger_event.trig_type == 1:
		start_trigger_event_enum = PMCLIB.Trace.SoftwareTrigger()
	if start_trigger_event.trig_type == 2:
		start_trigger_event_enum = PMCLIB.Trace.MotionStartTrigger(start_trigger_event.xbot_id)
	if start_trigger_event.trig_type == 3:
		start_trigger_event_enum = PMCLIB.Trace.MotionStopTrigger(start_trigger_event.xbot_id)
	if start_trigger_event.trig_type == 7:
		start_trigger_event_enum = PMCLIB.Trace.FieldbusTrigger(start_trigger_event.fb_trigger)


	rtn = TraceHelper.TraceFlywayPowerConsumption(int(flyway_id),float(trace_duration),start_trigger_event_enum)

	return SingleTrace(rtn)


def generate_software_trigger(
	xbot_id: int
):
	"""Generates a software trigger for the specified XBot.

	Parameters
	----------
	xbot_id: int
		The ID of the XBot to trigger. Use 0 to trigger all XBots.

	"""
	assert_type(xbot_id, int, "xbot_id")
	

	rtn = TraceHelper.GenerateSoftwareTrigger(int(xbot_id))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"generate_software_trigger command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def stop_and_deallocate_all_traces():
	"""Stops and deallocate all traces

	"""
	
	rtn = TraceHelper.StopAndDeallocateAllTraces()

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"stop_and_deallocate_all_traces command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)

