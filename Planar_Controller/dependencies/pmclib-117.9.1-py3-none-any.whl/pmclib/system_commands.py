from PMCLIB import SystemCommands as _sys
from PMCLIB import PMCRTN
import PMCLIB
from pmclib import pmc_types as pm
from pmclib.pmc_types import assert_type
from System import Enum
from typing import List
import datetime

__sys = _sys()


def auto_search_and_connect_to_pmc():
	"""automatically searches for and connects to an available PMC

	Returns
	-------
	bool
	"""
	
	rtn = __sys.AutoSearchAndConnectToPMC()
	return rtn


def connect_to_specific_pmc(
	ip_address: str
):
	"""connect to a specific PMC at the provided IP address

	Parameters
	----------
	ip_address: str
		IP Address of the PMC

	Returns
	-------
	bool
	"""
	assert_type(ip_address, str, "ip_address")
	

	rtn = __sys.ConnectToSpecificPMC(ip_address)
	return rtn


def check_tcp_connection():
	"""Check if the TCP connection to the PMC is up

	Returns
	-------
	TriState
	"""
	
	rtn = __sys.CheckTCPConnection()

	if rtn == PMCLIB.TriState.TRUE:
		return True
	else:
		return False


def disconnect_from_pmc():
	"""Disconnect the computer from the PMC

	Returns
	-------
	None n	"""
	
	__sys.DisconnectFromPMC()

def gain_mastership():
	"""Attempts to gain mastership of the PMC

	Returns
	-------
	PMCRTN
	"""
	
	rtn = __sys.GainMastership()

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"gain_mastership command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def release_mastership():
	"""Release mastership of the PMC

	Returns
	-------
	PMCRTN
	"""
	
	rtn = __sys.ReleaseMastership()

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"release_mastership command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def is_master():
	"""check whether current host is the master of the PMC

	Returns
	-------
	TriState
	"""
	
	rtn = __sys.IsMaster()

	if rtn == PMCLIB.TriState.TRUE:
		return True
	else:
		return False


def get_pmc_status():
	"""Gets the status of the PMC

	Returns
	-------
	PMCSTATUS
	"""
	
	rtn = __sys.GetPMCStatus()

	return pm.PMCSTATUS(int(rtn))


def get_pm_net_status():
	"""Gets the status of PMNet

	Returns
	-------
	TriState
	"""
	
	rtn = __sys.GetPMNetStatus()

	if rtn == PMCLIB.TriState.TRUE:
		return True
	else:
		return False


def reboot_pmc(
	mode: int
):
	"""Reboot the PMC

	Parameters
	----------
	mode: int
		
            Reboot mode:
            - 0 (Cold Reboot): Reboots both PMC and Fieldbus Communication.
            - 1 (Warm Reboot): Reboots only the PMC, without affecting Fieldbus Communication.
            

	Returns
	-------
	PMCRTN
	"""
	assert_type(mode, int, "mode")
	

	rtn = __sys.RebootPMC(int(mode))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"reboot_pmc command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def get_flyway_physical_status(
	flyway_id: int
):
	"""get the flyway physical status including power consumption, and various temperature measurements

	Parameters
	----------
	flyway_id: int
		flyway id

	Returns
	-------
	FlywayPhysicalStatus
	"""
	assert_type(flyway_id, int, "flyway_id")
	

	rtn = __sys.GetFlywayPhysicalStatus(int(flyway_id))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_flyway_physical_status command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return pm.FlywayPhysicalStatus(
		pm.PMCRTN(int(rtn.PmcRtn)),
		rtn.powerConsumptionW,
		rtn.cpuTempC,
		rtn.amplifierTempC,
		rtn.motorTempC

		)


def get_new_xbots_from_border():
	"""get a list of xbots that were received at PMC flyway border

	Returns
	-------
	BorderNewXbotRtn
	"""
	
	rtn = __sys.GetNewXbotsFromBorder()

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_new_xbots_from_border command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return pm.BorderNewXbotRtn(
		pm.PMCRTN(int(rtn.PmcRtn)),
		rtn.XBotCount,
		[x for x in rtn.XBotIDs],
		[x for x in rtn.BorderIDs]

		)


def get_border_status(
	border_id: int
):
	"""get the status of the border between PMC systems

	Parameters
	----------
	border_id: int
		 the border ID

	Returns
	-------
	BorderStatusRtn
	"""
	assert_type(border_id, int, "border_id")
	

	rtn = __sys.GetBorderStatus(int(border_id))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_border_status command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		pm.BORDERSTATUS(int(rtn.BorderStatus))



def get_all_gcode_ids():
	"""Gets the ID of all g-code files stored in the PMC

	Returns
	-------
	GCodeIDRtn
	"""
	
	rtn = __sys.GetAllGCodeIDs()

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_all_gcode_ids command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return pm.GCodeIDRtn(
		pm.PMCRTN(int(rtn.PmcRtn)),
		rtn.GCodeCount,
		[x for x in rtn.GCodeIDs]

		)


def read_gcode(
	gcode_id: int
):
	"""Read the g-code text for the specified g-code ID

	Parameters
	----------
	gcode_id: int
		 The g-code ID to read from 

	Returns
	-------
	GCodeRtn
	"""
	assert_type(gcode_id, int, "gcode_id")
	

	rtn = __sys.ReadGCode(int(gcode_id))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"read_gcode command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		rtn.GCodeText



def save_gcode(
	gcode_id: int,
	gcode_text: str
):
	"""Saves the g-code to the PMC with the associated g-code ID

	Parameters
	----------
	gcode_id: int
		 The ID to save the g-code at 
	gcode_text: str
		 The g-code text to save 

	Returns
	-------
	PMCRTN
	"""
	assert_type(gcode_id, int, "gcode_id")
	assert_type(gcode_text, str, "gcode_text")
	

	rtn = __sys.SaveGCode(int(gcode_id),gcode_text)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"save_gcode command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def delete_gcode(
	gcode_id: int
):
	"""Deletes the g-code with the associated g-code ID

	Parameters
	----------
	gcode_id: int
		 The ID of the g-code to delete 

	Returns
	-------
	PMCRTN
	"""
	assert_type(gcode_id, int, "gcode_id")
	

	rtn = __sys.DeleteGCode(int(gcode_id))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"delete_gcode command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def zone_control(
	zone_id: int,
	zone_op: pm.ZONEOPERATION
):
	"""control the zone

	Parameters
	----------
	zone_id: int
		Zone ID
	zone_op: pm.ZONEOPERATION
		Zone Operation, 0 = deactivate zone, 1 = activate zone

	Returns
	-------
	PMCRTN
	"""
	assert_type(zone_id, int, "zone_id")
	assert_type(zone_op, pm.ZONEOPERATION, "zone_op")
	
	zone_op_enum = PMCLIB.ZONEOPERATION(zone_op)

	rtn = __sys.ZoneControl(int(zone_id),zone_op_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"zone_control command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def add_xbots_to_zone(
	zone_id: int,
	xbot_types: List[pm.XBOTTYPE],
	x_position_m: List[float],
	y_position_m: List[float]
):
	"""Adds XBots to the zone in emulation mode

	Parameters
	----------
	zone_id: int
		 The ID of the zone to add XBots to 
	xbot_types: List[pm.XBOTTYPE]
		 An array containing the types of the XBot to add 
	x_position_m: List[float]
		 An array containing the X starting position of the XBots in m 
	y_position_m: List[float]
		 An array containing the Y starting position of the XBots in m 

	Returns
	-------
	PMCRTN
	"""
	assert_type(zone_id, int, "zone_id")
	
	xbot_types_enum = [PMCLIB.XBOTTYPE(x) for x in xbot_types]

	x_position_m = [float(x) for x in x_position_m]
	y_position_m = [float(x) for x in y_position_m]
	rtn = __sys.AddXBotsToZone(int(zone_id),xbot_types_enum,x_position_m,y_position_m)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"add_xbots_to_zone command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def remove_xbots_from_zone(
	zone_id: int
):
	"""Removes all the XBots inside a zone in emulation mode

	Parameters
	----------
	zone_id: int
		 The ID of the zone to remove XBots from

	Returns
	-------
	PMCRTN
	"""
	assert_type(zone_id, int, "zone_id")
	

	rtn = __sys.RemoveXBotsFromZone(int(zone_id))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"remove_xbots_from_zone command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def define_zone(
	zone_id: int,
	min_xm: float,
	min_ym: float,
	max_xm: float,
	max_ym: float
):
	"""Defines a custom zone region

	Parameters
	----------
	zone_id: int
		 The ID of the zone to be defined 
	min_xm: float
		 The X co-ordinate lower bounds of the zone in m 
	min_ym: float
		 The Y co-ordinate lower bounds of the zone in m 
	max_xm: float
		 The X co-ordinate upper bounds of the zone in m 
	max_ym: float
		 The Y co-ordinate upper bounds of the zone in m 

	Returns
	-------
	PMCRTN
	"""
	assert_type(zone_id, int, "zone_id")
	assert_type(min_xm, float, "min_xm")
	assert_type(min_ym, float, "min_ym")
	assert_type(max_xm, float, "max_xm")
	assert_type(max_ym, float, "max_ym")
	

	rtn = __sys.DefineZone(int(zone_id),float(min_xm),float(min_ym),float(max_xm),float(max_ym))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"define_zone command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def define_intersection_zone(
	zone_id: int,
	min_xm: float,
	min_ym: float,
	max_xm: float,
	max_ym: float,
	max_number_of_xbot: int
):
	"""Define a specialize zone, where only the user specified number of mover are allowed to move inside the zone at a time.

	Parameters
	----------
	zone_id: int
		 The ID of the zone to be defined 
	min_xm: float
		 The X co-ordinate lower bounds of the zone in m 
	min_ym: float
		 The Y co-ordinate lower bounds of the zone in m 
	max_xm: float
		 The X co-ordinate upper bounds of the zone in m 
	max_ym: float
		 The Y co-ordinate upper bounds of the zone in m 
	max_number_of_xbot: int
		Specifies maximum number of XBots allowed inside the zone

	Returns
	-------
	PMCRTN
	"""
	assert_type(zone_id, int, "zone_id")
	assert_type(min_xm, float, "min_xm")
	assert_type(min_ym, float, "min_ym")
	assert_type(max_xm, float, "max_xm")
	assert_type(max_ym, float, "max_ym")
	assert_type(max_number_of_xbot, int, "max_number_of_xbot")
	

	rtn = __sys.DefineIntersectionZone(int(zone_id),float(min_xm),float(min_ym),float(max_xm),float(max_ym),int(max_number_of_xbot))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"define_intersection_zone command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def define_z_limited_intersection_zone(
	zone_id: int,
	min_xm: float,
	min_ym: float,
	max_xm: float,
	max_ym: float,
	z_limit_m: float,
	max_number_of_xbot: int
):
	"""Define a specialize zone, where only the user specified number of mover with Z height less than the Z Limit are allowed to move inside the zone at a time.

	Parameters
	----------
	zone_id: int
		 The ID of the zone to be defined 
	min_xm: float
		 The X co-ordinate lower bounds of the zone in m 
	min_ym: float
		 The Y co-ordinate lower bounds of the zone in m 
	max_xm: float
		 The X co-ordinate upper bounds of the zone in m 
	max_ym: float
		 The Y co-ordinate upper bounds of the zone in m 
	z_limit_m: float
		 The Z limit for the zone in m. Xbots with or higher Z Height of the limit cannot enter the zone.
	max_number_of_xbot: int
		Specifies maximum number of XBots allowed inside the zone

	Returns
	-------
	PMCRTN
	"""
	assert_type(zone_id, int, "zone_id")
	assert_type(min_xm, float, "min_xm")
	assert_type(min_ym, float, "min_ym")
	assert_type(max_xm, float, "max_xm")
	assert_type(max_ym, float, "max_ym")
	assert_type(z_limit_m, float, "z_limit_m")
	assert_type(max_number_of_xbot, int, "max_number_of_xbot")
	

	rtn = __sys.DefineZLimitedIntersectionZone(int(zone_id),float(min_xm),float(min_ym),float(max_xm),float(max_ym),float(z_limit_m),int(max_number_of_xbot))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"define_z_limited_intersection_zone command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def override_zone(
	zone_id: int,
	velocity_factor: float,
	accel_factor: float
):
	"""Override the velocity and acceleration inside of a zone

	Parameters
	----------
	zone_id: int
		 The ID of the zone to override 
	velocity_factor: float
		 The factor that will be multiplied to XBot velocity inside the zone 
	accel_factor: float
		 The factor that will be multiplied to the XBot acceleration inside the zone 

	Returns
	-------
	PMCRTN
	"""
	assert_type(zone_id, int, "zone_id")
	assert_type(velocity_factor, float, "velocity_factor")
	assert_type(accel_factor, float, "accel_factor")
	

	rtn = __sys.OverrideZone(int(zone_id),float(velocity_factor),float(accel_factor))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"override_zone command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def zone_fence_control(
	zone_id: int,
	fence_op: pm.FENCEOPERATION
):
	"""control the zone fence

	Parameters
	----------
	zone_id: int
		Zone ID
	fence_op: pm.FENCEOPERATION
		Zone Operation, 0 = remove the fence, 1 = build the fence

	Returns
	-------
	PMCRTN
	"""
	assert_type(zone_id, int, "zone_id")
	assert_type(fence_op, pm.FENCEOPERATION, "fence_op")
	
	fence_op_enum = PMCLIB.FENCEOPERATION(fence_op)

	rtn = __sys.ZoneFenceControl(int(zone_id),fence_op_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"zone_fence_control command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def get_zone_status(
	zone_id: int
):
	"""returns the zone state and the list of XBots inside the zone

	Parameters
	----------
	zone_id: int
		zone id

	Returns
	-------
	ZoneStatusReturn
	"""
	assert_type(zone_id, int, "zone_id")
	

	rtn = __sys.GetZoneStatus(int(zone_id))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_zone_status command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return pm.ZoneStatusReturn(
		pm.PMCRTN(int(rtn.PmcRtn)),
		pm.ZONESTATE(int(rtn.ZoneState)),
		rtn.XBotCount,
		[x for x in rtn.XBotIDs],
		rtn.XBotCountOnBorder,
		[x for x in rtn.XBotIDsOnBorder],
		rtn.SpeedOverrideRatio,
		rtn.AccelerationOverrideRatio

		)


def save_pmc_config_xml_file(
	path: str
):
	"""saves the current PMC configuration to a xml file at the specified path

	Parameters
	----------
	path: str
		the path to save the configuration file to

	Returns
	-------
	PMCRTN
	"""
	assert_type(path, str, "path")
	

	rtn = __sys.SavePMCConfigXMLFile(path)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"save_pmc_config_xml_file command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def enter_service_mode():
	"""Enters PMC Service Mode

	Returns
	-------
	PMCRTN
	"""
	
	rtn = __sys.EnterServiceMode()

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"enter_service_mode command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def exit_service_mode():
	"""Exits PMC Service Mode

	Returns
	-------
	PMCRTN
	"""
	
	rtn = __sys.ExitServiceMode()

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"exit_service_mode command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def sector_control(
	sector_id: int,
	sector_operation: pm.SECTOROPERATION
):
	"""activate/deactivate specific sector

	Parameters
	----------
	sector_id: int
		 sector ID(>0) 
	sector_operation: pm.SECTOROPERATION
		 sector control level, 0 = deactivate sector, 1 = activate sector 

	Returns
	-------
	PMCRTN
	"""
	assert_type(sector_id, int, "sector_id")
	assert_type(sector_operation, pm.SECTOROPERATION, "sector_operation")
	
	sector_operation_enum = PMCLIB.SECTOROPERATION(sector_operation)

	rtn = __sys.SectorControl(int(sector_id),sector_operation_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"sector_control command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def sector_recover(
	sector_id: int
):
	"""remove sector fences after it's activated

	Parameters
	----------
	sector_id: int
		 sector ID(>0) 

	Returns
	-------
	PMCRTN
	"""
	assert_type(sector_id, int, "sector_id")
	

	rtn = __sys.SectorRecover(int(sector_id))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"sector_recover command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def get_sector_status(
	sector_id: int
):
	"""returns the sector state and the list of XBots inside the sector

	Parameters
	----------
	sector_id: int
		sector ID

	Returns
	-------
	SectorStatusReturn
	"""
	assert_type(sector_id, int, "sector_id")
	

	rtn = __sys.GetSectorStatus(int(sector_id))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_sector_status command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return pm.SectorStatusReturn(
		pm.PMCRTN(int(rtn.PmcRtn)),
		pm.SECTORSTATE(int(rtn.SectorState)),
		rtn.XBotCount,
		[x for x in rtn.XBotIDs],
		rtn.XBotCountOnBorder,
		[x for x in rtn.XBotIDsOnBorder]

		)


def read_external_digital_input():
	"""Reads the external signal from the PMC

	Returns
	-------
	ReadExternalSignalRtn
	"""
	
	rtn = __sys.ReadExternalDigitalInput()

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"read_external_digital_input command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		rtn.Signal



def write_external_digital_output(
	signal: bool
):
	"""Writes the external signal to the PMC

	Parameters
	----------
	signal: bool
		Digital Signal HIGH = true, LOW = false)

	Returns
	-------
	PMCRTN
	"""
	assert_type(signal, bool, "signal")
	

	rtn = __sys.WriteExternalDigitalOutput(bool(signal))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"write_external_digital_output command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def get_pmc_time():
	"""Gets the current PMC time

	Returns
	-------
	GetPMCTimeRtn
	"""
	
	rtn = __sys.GetPMCTime()

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_pmc_time command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		rtn.PmcTime



def set_pmc_time(
	time: datetime.datetime
):
	"""Sets the current PMC Time

	Parameters
	----------
	time: datetime.datetime
		Desired PMC Time as a Date Time Object. Year, Month, Day, Hour, Minute and Second

	Returns
	-------
	PMCRTN
	"""
	assert_type(time, datetime.datetime, "time")
	

	rtn = __sys.SetPMCTime(time)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"set_pmc_time command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def reset_xbot_ids():
	"""Resets scanned Xbot IDs

	Returns
	-------
	PMCRTN
	"""
	
	rtn = __sys.ResetXbotIDs()

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"reset_xbot_ids command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def delete_log_info(
	log_type: pm.LOGTYPE
):
	"""Deletes the content of log files (Warning log and error log)

	Parameters
	----------
	log_type: pm.LOGTYPE
		logType

	Returns
	-------
	PMCRTN
	"""
	assert_type(log_type, pm.LOGTYPE, "log_type")
	
	log_type_enum = PMCLIB.LOGTYPE(log_type)

	rtn = __sys.DeleteLogInfo(log_type_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"delete_log_info command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def set_trajectory(
	trajectory_id: int,
	time_interval: float,
	axes_definition: pm.TrajectoryAxesDefinition,
	trajectory: str
):
	"""Sets new trajectory to PMC

	Parameters
	----------
	trajectory_id: int
		ID of the new trajectory
	time_interval: float
		Trajectory's time interval in second
	axes_definition: pm.TrajectoryAxesDefinition
		Represents which axes are defined. Default is false for al axis, set to true if the axis is defined.
	trajectory: str
		Trajectory as string

	Returns
	-------
	PMCRTN
	"""
	assert_type(trajectory_id, int, "trajectory_id")
	assert_type(time_interval, float, "time_interval")
	assert_type(axes_definition, pm.TrajectoryAxesDefinition, "axes_definition")
	assert_type(trajectory, str, "trajectory")
	
	axes_definition_enum = PMCLIB.TrajectoryAxesDefinition()
	axes_definition_enum.XAxis = axes_definition.x_axis
	axes_definition_enum.YAxis = axes_definition.y_axis
	axes_definition_enum.ZAxis = axes_definition.z_axis
	axes_definition_enum.RxAxis = axes_definition.rx_axis
	axes_definition_enum.RyAxis = axes_definition.ry_axis
	axes_definition_enum.RzAxis = axes_definition.rz_axis
	axes_definition_enum.DigitalInput = axes_definition.digital_input


	rtn = __sys.SetTrajectory(int(trajectory_id),float(time_interval),axes_definition_enum,trajectory)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"set_trajectory command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def save_design_file_to_pc(
	design_id: int,
	file_path: str
):
	"""Save a design file to PC

	Parameters
	----------
	design_id: int
		design ID stored on the PMC
	file_path: str
		path to file including file name and format (.json)

	Returns
	-------
	PMCRTN
	"""
	assert_type(design_id, int, "design_id")
	assert_type(file_path, str, "file_path")
	

	rtn = __sys.SaveDesignFileToPC(int(design_id),file_path)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"save_design_file_to_pc command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def send_xbot_to_station(
	cmd_label: int,
	xbot_id: int,
	station_id: int,
	bay_id: int,
	wait_for_free_bay: bool
):
	"""Send a xbot to a station

	Parameters
	----------
	cmd_label: int
		command label
	xbot_id: int
		xbot ID
	station_id: int
		station ID
	bay_id: int
		bay ID, if 0 then the PMC will pick the bay
	wait_for_free_bay: bool
		whether to wait for a free bay before moving

	Returns
	-------
	PMCRTN
	"""
	assert_type(cmd_label, int, "cmd_label")
	assert_type(xbot_id, int, "xbot_id")
	assert_type(station_id, int, "station_id")
	assert_type(bay_id, int, "bay_id")
	assert_type(wait_for_free_bay, bool, "wait_for_free_bay")
	

	rtn = __sys.SendXbotToStation(int(cmd_label),int(xbot_id),int(station_id),int(bay_id),bool(wait_for_free_bay))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"send_xbot_to_station command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def get_idle_xbot_id_in_bay(
	station_id: int,
	bay_id: int
):
	"""Get the xbot ID currently in a bay, if it is idle

	Parameters
	----------
	station_id: int
		station ID
	bay_id: int
		bay ID

	Returns
	-------
	BayXbotId
	"""
	assert_type(station_id, int, "station_id")
	assert_type(bay_id, int, "bay_id")
	

	rtn = __sys.GetIdleXbotIdInBay(int(station_id),int(bay_id))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_idle_xbot_id_in_bay command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return pm.BayXbotId(
		pm.PMCRTN(int(rtn.PmcRtn)),
		rtn.BayId,
		rtn.XbotId

		)


def get_any_xbot_id_in_bay(
	station_id: int,
	bay_id: int
):
	"""Get the xbot ID currently in a station (any xbot state)

	Parameters
	----------
	station_id: int
		station ID
	bay_id: int
		bay ID

	Returns
	-------
	BayXbotId
	"""
	assert_type(station_id, int, "station_id")
	assert_type(bay_id, int, "bay_id")
	

	rtn = __sys.GetAnyXbotIdInBay(int(station_id),int(bay_id))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_any_xbot_id_in_bay command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return pm.BayXbotId(
		pm.PMCRTN(int(rtn.PmcRtn)),
		rtn.BayId,
		rtn.XbotId

		)


def get_xbot_id_in_bay(
	station_id: int,
	bay_id: int,
	filter_states: List[pm.XBOTSTATE]
):
	"""Get the xbot ID currently in a station that has any of the specified xbot states

	Parameters
	----------
	station_id: int
		station ID
	bay_id: int
		bay ID
	filter_states: List[pm.XBOTSTATE]
		filter for xbot states the xbot can be in

	Returns
	-------
	BayXbotId
	"""
	assert_type(station_id, int, "station_id")
	assert_type(bay_id, int, "bay_id")
	
	filter_states_enum = [PMCLIB.XBOTSTATE(x) for x in filter_states]

	rtn = __sys.GetXbotIdInBay(int(station_id),int(bay_id),filter_states_enum)

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_xbot_id_in_bay command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return pm.BayXbotId(
		pm.PMCRTN(int(rtn.PmcRtn)),
		rtn.BayId,
		rtn.XbotId

		)


def get_idle_xbot_ids_in_station(
	station_id: int
):
	"""Get all idle xbot IDs currently in the station

	Parameters
	----------
	station_id: int
		station ID

	Returns
	-------
	StationXbotIds
	"""
	assert_type(station_id, int, "station_id")
	

	rtn = __sys.GetIdleXbotIdsInStation(int(station_id))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_idle_xbot_ids_in_station command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return pm.StationXbotIds(
		pm.PMCRTN(int(rtn.PmcRtn)),
		rtn.StationId,
		[		pm.BayXbotId(
		pm.PMCRTN(int(x.PmcRtn)),
		x.BayId,
		x.XbotId
		)
		for x in rtn.BayXbotIds
	],		[x for x in rtn.XbotIds]

		)


def get_any_xbot_ids_in_station(
	station_id: int
):
	"""Get xbot IDs currently in the station (any xbot state)

	Parameters
	----------
	station_id: int
		station ID

	Returns
	-------
	StationXbotIds
	"""
	assert_type(station_id, int, "station_id")
	

	rtn = __sys.GetAnyXbotIdsInStation(int(station_id))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_any_xbot_ids_in_station command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return pm.StationXbotIds(
		pm.PMCRTN(int(rtn.PmcRtn)),
		rtn.StationId,
		[		pm.BayXbotId(
		pm.PMCRTN(int(x.PmcRtn)),
		x.BayId,
		x.XbotId
		)
		for x in rtn.BayXbotIds
	],		[x for x in rtn.XbotIds]

		)


def get_xbot_ids_in_station(
	station_id: int,
	filter_states: List[pm.XBOTSTATE]
):
	"""Get the xbot IDs currently in the station that have any of the specified xbot states

	Parameters
	----------
	station_id: int
		stationID
	filter_states: List[pm.XBOTSTATE]
		filter for xbot states the xbots can be in

	Returns
	-------
	StationXbotIds
	"""
	assert_type(station_id, int, "station_id")
	
	filter_states_enum = [PMCLIB.XBOTSTATE(x) for x in filter_states]

	rtn = __sys.GetXbotIdsInStation(int(station_id),filter_states_enum)

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_xbot_ids_in_station command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return pm.StationXbotIds(
		pm.PMCRTN(int(rtn.PmcRtn)),
		rtn.StationId,
		[		pm.BayXbotId(
		pm.PMCRTN(int(x.PmcRtn)),
		x.BayId,
		x.XbotId
		)
		for x in rtn.BayXbotIds
	],		[x for x in rtn.XbotIds]

		)


def get_any_xbot_ids_in_all_stations():
	"""Get all xbot IDs currently in all stations (any xbot state)

	Returns
	-------
	AllStationXbotIds
	"""
	
	rtn = __sys.GetAnyXbotIdsInAllStations()

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_any_xbot_ids_in_all_stations command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		[		pm.StationXbotIds(
		pm.PMCRTN(int(x.PmcRtn)),
		x.StationId,
		[		pm.BayXbotId(y.PmcRtn,
		y.BayId,
		y.XbotId,
		)for y in x.BayXbotIds],
				[y for y in x.XbotIds]
		)
		for x in rtn.StationXbotIds
	]


def get_xbot_ids_in_all_stations(
	filter_states: List[pm.XBOTSTATE]
):
	"""Get the xbot IDs currently in all stations that have any of the specified xbot states

	Parameters
	----------
	filter_states: List[pm.XBOTSTATE]
		filter for xbot states the xbots can be in

	Returns
	-------
	AllStationXbotIds
	"""
	
	filter_states_enum = [PMCLIB.XBOTSTATE(x) for x in filter_states]

	rtn = __sys.GetXbotIdsInAllStations(filter_states_enum)

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_xbot_ids_in_all_stations command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		[		pm.StationXbotIds(
		pm.PMCRTN(int(x.PmcRtn)),
		x.StationId,
		[		pm.BayXbotId(y.PmcRtn,
		y.BayId,
		y.XbotId,
		)for y in x.BayXbotIds],
				[y for y in x.XbotIds]
		)
		for x in rtn.StationXbotIds
	]


def get_xbot_target_station(
	xbot_id: int
):
	"""Get the target station for a xbot

	Parameters
	----------
	xbot_id: int
		xbot ID

	Returns
	-------
	TargetStation
	"""
	assert_type(xbot_id, int, "xbot_id")
	

	rtn = __sys.GetXbotTargetStation(int(xbot_id))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_xbot_target_station command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return pm.TargetStation(
		pm.PMCRTN(int(rtn.PmcRtn)),
		rtn.StationId,
		rtn.BayId

		)

